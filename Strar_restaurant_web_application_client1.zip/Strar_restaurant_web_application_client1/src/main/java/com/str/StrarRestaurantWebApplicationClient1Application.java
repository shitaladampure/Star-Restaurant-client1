package com.str;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrarRestaurantWebApplicationClient1Application {

	public static void main(String[] args) {
		SpringApplication.run(StrarRestaurantWebApplicationClient1Application.class, args);
	}

}
