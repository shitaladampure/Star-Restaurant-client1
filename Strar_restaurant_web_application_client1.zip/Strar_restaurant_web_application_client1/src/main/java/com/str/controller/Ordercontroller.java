package com.str.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.str.model.Order;
import com.str.service.OrderServiceI;

@RestController
@RequestMapping("/order")
public class Ordercontroller {
	@Autowired
	public OrderServiceI j;
	@PostMapping("/add")
	public void addorderdata(@RequestBody Order order) {
		j.addorder(order);
	}
@GetMapping("/getorder")
public List<Order>getorderdata(@PathVariable int id){
	List<Order>list= j.getorderdata(id);
	return list;
}
@PutMapping("/update")
public void updateorderdata(@RequestBody Order order) {
	j.updateorder(order);
}
@DeleteMapping("/delete/{id}")
public void deleteorderdata(@PathVariable int id) {
	j.deleteorder(id);
}
}
