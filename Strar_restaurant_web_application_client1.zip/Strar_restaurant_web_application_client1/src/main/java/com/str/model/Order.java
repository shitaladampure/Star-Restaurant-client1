package com.str.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Order {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int id;
private String date;
private String location;
private String status;
private String food;
private String time;
private String quntity;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getFood() {
	return food;
}
public void setFood(String food) {
	this.food = food;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getQuntity() {
	return quntity;
}
public void setQuntity(String quntity) {
	this.quntity = quntity;
}
@Override
public String toString() {
	return "Order [id=" + id + ", date=" + date + ", location=" + location + ", status=" + status + ", food=" + food
			+ ", time=" + time + ", quntity=" + quntity + "]";
}

}
