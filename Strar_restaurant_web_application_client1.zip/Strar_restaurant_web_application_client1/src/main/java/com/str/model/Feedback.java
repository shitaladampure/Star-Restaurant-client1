package com.str.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Feedback {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String  name;
	private String ratingstar;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRatingstar() {
		return ratingstar;
	}
	public void setRatingstar(String ratingstar) {
		this.ratingstar = ratingstar;
	}
	@Override
	public String toString() {
		return "Feedback [name=" + name + ", ratingstar=" + ratingstar + "]";
	}
	

}
