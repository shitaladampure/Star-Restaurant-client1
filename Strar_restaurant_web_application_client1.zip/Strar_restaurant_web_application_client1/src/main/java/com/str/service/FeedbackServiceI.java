package com.str.service;

import java.util.List;

import com.str.model.Feedback;

public interface FeedbackServiceI {
public void addfeedback(Feedback feedback);
public List<Feedback>getfeedbackdata(int id);
}
