package com.str.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.str.dao.OrderdaoI;
import com.str.model.Order;

@Service
public class OrderServiceImpl implements OrderServiceI {
@Autowired
private OrderdaoI h;

@Override
public void addorder(Order order) {
	// TODO Auto-generated method stub
	h.save(order);
}

@Override
public List<Order> getorderdata(int id) {
	// TODO Auto-generated method stub
	List<Order>list= h.findAll();
	return list;
}

@Override
public void updateorder(Order order) {
	// TODO Auto-generated method stub
	h.save(order);
}

@Override
public void deleteorder(int id) {
	// TODO Auto-generated method stub
	h.deleteById(id);
}
}
