package com.str.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.str.dao.FeedbackdaoI;
import com.str.model.Feedback;

@Service
public class FeedbackServiceImpl implements FeedbackServiceI {
@Autowired
private FeedbackdaoI k;

@Override
public void addfeedback(Feedback feedback) {
	// TODO Auto-generated method stub
	k.save(feedback);
}

@Override
public List<Feedback> getfeedbackdata(int id) {
	// TODO Auto-generated method stub
	List<Feedback>list= k.findAll();
	return list;
}
}

