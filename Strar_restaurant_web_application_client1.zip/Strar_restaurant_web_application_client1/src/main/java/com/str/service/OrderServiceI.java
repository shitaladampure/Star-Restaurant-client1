package com.str.service;

import java.util.List;

import com.str.model.Order;

public interface OrderServiceI {
public  void addorder(Order order);
public List<Order>getorderdata(int id);
public void updateorder(Order order);
public void deleteorder(int id);
}
