package com.str.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.str.model.Order;

@Repository
public interface OrderdaoI extends JpaRepository<Order, Integer> {

}
